rootProject.name = "Holly2_TWA"
include(":app")
